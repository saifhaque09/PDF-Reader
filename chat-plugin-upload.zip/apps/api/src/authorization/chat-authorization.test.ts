import { strict as assert } from 'node:assert';
import test from 'node:test';
import { ChatAuthorizationService } from './chat-authorization';

const setup = (overrides: Partial<{ active: boolean; clientAccess: boolean; permission: boolean; targetActive: boolean; targetClientAccess: boolean }> = {}) => {
  const state = { active: true, clientAccess: true, permission: true, targetActive: true, targetClientAccess: true, ...overrides };
  const portal = {
    getUser: async (id: string) => id === 'target' ? { id, active: state.targetActive } : { id, active: state.active },
    canAccessClient: async (id: string) => id === 'target' ? state.targetClientAccess : state.clientAccess,
    hasPermission: async () => state.permission,
  };
  const chat = {
    getConversation: async () => ({ id: 'c1', clientId: 'client-1', status: 'ACTIVE' as const }),
    getParticipant: async (_conversationId: string, userId: string) => ({ conversationId: 'c1', userId, role: userId === 'owner' ? 'OWNER' as const : 'MEMBER' as const, status: 'ACTIVE' as const }),
    getAttachment: async () => ({ id: 'a1', conversationId: 'c1' }),
  };
  return new ChatAuthorizationService(portal, chat);
};

test('authorized user can access and send in a conversation', async () => {
  const auth = setup();
  assert.equal(await auth.canAccessConversation('user', 'c1'), true);
  assert.equal(await auth.canSendMessage('user', 'c1'), true);
});

test('unauthorized, inactive, no-access, and revoked users are denied', async () => {
  assert.equal(await setup({ permission: false }).canAccessConversation('user', 'c1'), false);
  assert.equal(await setup({ active: false }).canAccessConversation('user', 'c1'), false);
  assert.equal(await setup({ clientAccess: false }).canAccessConversation('user', 'c1'), false);
  assert.equal(await setup({ clientAccess: false }).canSendMessage('user', 'c1'), false);
});

test('authorized group participant can manage participants', async () => {
  const auth = setup();
  assert.equal(await auth.canAddParticipant('owner', 'c1', 'target'), true);
});

test('unauthorized group participant cannot add or remove participants', async () => {
  const auth = setup();
  assert.equal(await auth.canAddParticipant('user', 'c1', 'target'), false);
  assert.equal(await auth.canRemoveParticipant('user', 'c1', 'target'), false);
});

test('target must be active and retain client access', async () => {
  assert.equal(await setup({ targetActive: false }).canAddParticipant('owner', 'c1', 'target'), false);
  assert.equal(await setup({ targetClientAccess: false }).canAddParticipant('owner', 'c1', 'target'), false);
});
