export type PortalUser = { id: string; active: boolean };

export type ChatConversation = {
  id: string;
  clientId: string | null;
  status: 'ACTIVE' | 'ARCHIVED';
};

export type ChatParticipant = {
  conversationId: string;
  userId: string;
  role: 'OWNER' | 'ADMIN' | 'MEMBER';
  status: 'ACTIVE' | 'LEFT';
};

export type ChatAttachment = { id: string; conversationId: string };

export interface PortalAuthorization {
  getUser(userId: string): Promise<PortalUser | null>;
  canAccessClient(userId: string, clientId: string): Promise<boolean>;
  hasPermission(userId: string, permission: string, clientId: string | null): Promise<boolean>;
}

// IdentityProvider is intentionally structurally compatible with this contract.
// Replace LocalIdentityProvider with an AccountingPortalIdentityProvider later.

export interface ChatAuthorizationRepository {
  getConversation(conversationId: string): Promise<ChatConversation | null>;
  getParticipant(conversationId: string, userId: string): Promise<ChatParticipant | null>;
  getAttachment(attachmentId: string): Promise<ChatAttachment | null>;
}

export class ChatAuthorizationService {
  constructor(
    private readonly portal: PortalAuthorization,
    private readonly chat: ChatAuthorizationRepository,
  ) {}

  async canAccessConversation(userId: string, conversationId: string): Promise<boolean> {
    const context = await this.getConversationContext(userId, conversationId);
    if (!context) return false;
    return this.portal.hasPermission(userId, 'chat.conversations.view', context.conversation.clientId);
  }

  async canSendMessage(userId: string, conversationId: string): Promise<boolean> {
    const context = await this.getConversationContext(userId, conversationId);
    if (!context || context.conversation.status !== 'ACTIVE') return false;
    return this.portal.hasPermission(userId, 'chat.messages.send', context.conversation.clientId);
  }

  async canViewAttachment(userId: string, attachmentId: string): Promise<boolean> {
    const attachment = await this.chat.getAttachment(attachmentId);
    if (!attachment || !await this.canAccessConversation(userId, attachment.conversationId)) return false;
    const conversation = await this.chat.getConversation(attachment.conversationId);
    return !!conversation && this.portal.hasPermission(userId, 'chat.attachments.view', conversation.clientId);
  }

  async canAddParticipant(userId: string, conversationId: string, targetUserId: string): Promise<boolean> {
    const context = await this.getConversationContext(userId, conversationId);
    if (!context || !['OWNER', 'ADMIN'].includes(context.participant.role)) return false;
    const target = await this.portal.getUser(targetUserId);
    if (!target?.active) return false;
    if (context.conversation.clientId && !await this.portal.canAccessClient(targetUserId, context.conversation.clientId)) return false;
    return this.portal.hasPermission(userId, 'chat.participants.manage', context.conversation.clientId);
  }

  async canRemoveParticipant(userId: string, conversationId: string, targetUserId: string): Promise<boolean> {
    const context = await this.getConversationContext(userId, conversationId);
    if (!context || !['OWNER', 'ADMIN'].includes(context.participant.role)) return false;
    if (userId === targetUserId && context.participant.role === 'OWNER') return false;
    return this.portal.hasPermission(userId, 'chat.participants.manage', context.conversation.clientId);
  }

  private async getConversationContext(userId: string, conversationId: string) {
    const [portalUser, conversation, participant] = await Promise.all([
      this.portal.getUser(userId),
      this.chat.getConversation(conversationId),
      this.chat.getParticipant(conversationId, userId),
    ]);
    if (!portalUser?.active || !conversation || conversation.status !== 'ACTIVE' || !participant || participant.status !== 'ACTIVE') return null;
    if (conversation.clientId && !await this.portal.canAccessClient(userId, conversation.clientId)) return null;
    return { conversation, participant };
  }
}
