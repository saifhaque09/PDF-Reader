import { Injectable } from '@nestjs/common';
import type { ContactSearch, IdentityProvider, IdentityUser } from './identity-provider';

const users: IdentityUser[] = [
  { id: 'user-owner', displayName: 'Alex Morgan', email: 'alex@example.test', active: true, category: 'INTERNAL' },
  { id: 'user-client', displayName: 'Sarah Carter', email: 'sarah@example.test', active: true, category: 'CLIENT' },
  { id: 'user-team', displayName: 'Michael Thompson', email: 'michael@example.test', active: true, category: 'INTERNAL' },
  { id: 'user-inactive', displayName: 'Inactive User', email: 'inactive@example.test', active: false, category: 'CLIENT' },
];

const clientAccess: Record<string, string[]> = { 'user-owner': ['client-abc'], 'user-client': ['client-abc'], 'user-team': ['client-abc'], 'user-inactive': ['client-abc'] };
const permissions: Record<string, string[]> = { 'user-owner': ['chat.conversations.view', 'chat.messages.send', 'chat.participants.manage', 'chat.attachments.view'], 'user-client': ['chat.conversations.view', 'chat.messages.send'], 'user-inactive': [] };

@Injectable()
export class LocalIdentityProvider implements IdentityProvider {
  async getUser(userId: string) { return users.find((user) => user.id === userId) ?? null; }

  async searchAuthorizedContacts(requestingUserId: string, filters: ContactSearch) {
    const result = users.filter((user) => user.active && user.id !== requestingUserId && (!filters.category || user.category === filters.category) && (!filters.query || `${user.displayName} ${user.email}`.toLowerCase().includes(filters.query.toLowerCase())) && (!filters.clientId || (clientAccess[user.id] ?? []).includes(filters.clientId)) && (!filters.clientId || (clientAccess[requestingUserId] ?? []).includes(filters.clientId)));
    return result;
  }

  async canAccessClient(userId: string, clientId: string) { return (await this.getUser(userId))?.active === true && (clientAccess[userId] ?? []).includes(clientId); }
  async hasPermission(userId: string, permission: string, clientId: string | null) { return (await this.getUser(userId))?.active === true && (!clientId || await this.canAccessClient(userId, clientId)) && (permissions[userId] ?? []).includes(permission); }
}
