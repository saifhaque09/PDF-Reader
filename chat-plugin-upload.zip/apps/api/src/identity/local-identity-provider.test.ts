import { strict as assert } from 'node:assert';
import test from 'node:test';
import { LocalIdentityProvider } from './local-identity-provider';

test('local provider returns only active contacts authorized for the requested client', async () => {
  const provider = new LocalIdentityProvider();
  const contacts = await provider.searchAuthorizedContacts('user-owner', { clientId: 'client-abc' });
  assert.deepEqual(contacts.map((contact) => contact.id), ['user-client']);
});

test('local provider excludes inactive contacts and unauthorized searches', async () => {
  const provider = new LocalIdentityProvider();
  assert.equal((await provider.searchAuthorizedContacts('user-owner', { query: 'inactive' })).length, 0);
  assert.equal(await provider.canAccessClient('user-client', 'client-other'), false);
});
