export type IdentityUser = { id: string; displayName: string; email: string; active: boolean; category: 'CLIENT' | 'INTERNAL' };

export type ContactSearch = { query?: string; clientId?: string; category?: IdentityUser['category']; recentOnly?: boolean };
export type AccountingRecordType = 'TAX_RETURN' | 'DOCUMENT_REQUEST' | 'PAYROLL' | 'TASK' | 'ENGAGEMENT';

export interface IdentityProvider {
  getUser(userId: string): Promise<IdentityUser | null>;
  searchAuthorizedContacts(requestingUserId: string, filters: ContactSearch): Promise<IdentityUser[]>;
  canAccessClient(userId: string, clientId: string): Promise<boolean>;
  hasPermission(userId: string, permission: string, clientId: string | null): Promise<boolean>;
}
