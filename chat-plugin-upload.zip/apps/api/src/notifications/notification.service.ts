import type { IdentityProvider } from '../identity/identity-provider';

export type NotificationType = 'NEW_MESSAGE' | 'MENTION' | 'ADDED_TO_GROUP' | 'REMOVED_FROM_GROUP' | 'CONVERSATION_EVENT';
export type NotificationPreference = 'ALL_MESSAGES' | 'MENTIONS_ONLY' | 'MUTED';
export type Notification = { id: string; userId: string; conversationId: string; type: NotificationType; status: 'UNREAD' | 'READ'; createdAt: string; message?: string };
export interface NotificationRepository { create(input: Omit<Notification, 'id' | 'createdAt'>): Promise<Notification>; listUnread(userId: string): Promise<Notification[]>; markRead(userId: string, notificationId: string): Promise<void>; }
export interface ConversationNotificationContext { participantIds: string[]; mutedUserIds: string[]; preferences: Record<string, NotificationPreference>; }

export class NotificationService {
  constructor(private readonly identity: IdentityProvider, private readonly repository: NotificationRepository) {}

  async notify(input: { actorId?: string; conversationId: string; type: NotificationType; message?: string; recipients: ConversationNotificationContext }) {
    const created: Notification[] = [];
    for (const userId of input.recipients.participantIds) {
      if (userId === input.actorId || !(await this.identity.getUser(userId))?.active) continue;
      const preference = input.recipients.preferences[userId] ?? 'ALL_MESSAGES';
      const isMention = input.type === 'MENTION';
      const muted = input.recipients.mutedUserIds.includes(userId) || preference === 'MUTED';
      if (muted || (preference === 'MENTIONS_ONLY' && !isMention)) continue;
      created.push(await this.repository.create({ userId, conversationId: input.conversationId, type: input.type, status: 'UNREAD', message: input.message }));
    }
    return created;
  }

  async unread(userId: string) { if (!(await this.identity.getUser(userId))?.active) return []; return this.repository.listUnread(userId); }
  async markRead(userId: string, notificationId: string) { if ((await this.identity.getUser(userId))?.active) await this.repository.markRead(userId, notificationId); }
}
