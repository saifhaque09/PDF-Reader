import type { ChatAuthorizationService } from '../authorization/chat-authorization';

export type AccessAction = 'VIEW' | 'DOWNLOAD' | 'ACCESS_DENIED';
export type ViewerAttachment = { id: string; messageId: string; originalFileName: string; mimeType: string; fileSize: number; status: 'AVAILABLE' | 'BLOCKED' | 'QUARANTINED' | 'FAILED' | 'DELETED'; conversationId: string; linkedRecordType?: string; linkedRecordId?: string };
export interface ViewerRepository { getAttachment(id: string): Promise<ViewerAttachment | null>; recordAccess(input: { attachmentId: string; userId: string; action: AccessAction; ipAddress?: string }): Promise<void>; }
export interface SignedStorage { createSignedUrl(storageId: string, options: { expiresInSeconds: number; disposition: 'inline' | 'attachment' }): Promise<string>; }

export class AttachmentViewerService {
  constructor(private readonly auth: ChatAuthorizationService, private readonly repository: ViewerRepository, private readonly storage: SignedStorage) {}

  async getAccess(userId: string, attachmentId: string, action: 'VIEW' | 'DOWNLOAD', ipAddress?: string) {
    const attachment = await this.repository.getAttachment(attachmentId);
    const allowed = !!attachment && attachment.status === 'AVAILABLE' && await this.auth.canViewAttachment(userId, attachmentId);
    if (!allowed) { await this.repository.recordAccess({ attachmentId, userId, action: 'ACCESS_DENIED', ipAddress }); throw new Error('ATTACHMENT_ACCESS_DENIED'); }
    await this.repository.recordAccess({ attachmentId, userId, action, ipAddress });
    return { attachment, url: await this.storage.createSignedUrl(attachment.id, { expiresInSeconds: 300, disposition: action === 'VIEW' ? 'inline' : 'attachment' }) };
  }
}
