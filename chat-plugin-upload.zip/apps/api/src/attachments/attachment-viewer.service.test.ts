import { strict as assert } from 'node:assert';
import test from 'node:test';
import { AttachmentViewerService } from './attachment-viewer.service';

const setup = (allowed = true, status: any = 'AVAILABLE') => { const logs: any[] = []; const repository = { getAttachment: async () => ({ id: 'a1', messageId: 'm1', originalFileName: 'tax.pdf', mimeType: 'application/pdf', fileSize: 10, status, conversationId: 'c1' }), recordAccess: async (log: any) => logs.push(log) }; const auth = { canViewAttachment: async () => allowed } as any; const storage = { createSignedUrl: async (_id: string, options: any) => `signed://${options.disposition}/expires-300` }; return { service: new AttachmentViewerService(auth, repository, storage), logs }; };

test('authorized view returns a short-lived inline URL and records VIEW', async () => { const { service, logs } = setup(); const result = await service.getAccess('u1', 'a1', 'VIEW'); assert.equal(result.url, 'signed://inline/expires-300'); assert.equal(logs[0].action, 'VIEW'); });
test('authorized download returns attachment disposition and records DOWNLOAD', async () => { const { service, logs } = setup(); const result = await service.getAccess('u1', 'a1', 'DOWNLOAD'); assert.equal(result.url, 'signed://attachment/expires-300'); assert.equal(logs[0].action, 'DOWNLOAD'); });
test('unauthorized and unavailable files are denied and audited', async () => { const denied = setup(false); await assert.rejects(() => denied.service.getAccess('u1', 'a1', 'VIEW'), /ACCESS_DENIED/); assert.equal(denied.logs[0].action, 'ACCESS_DENIED'); const unavailable = setup(true, 'BLOCKED'); await assert.rejects(() => unavailable.service.getAccess('u1', 'a1', 'DOWNLOAD'), /ACCESS_DENIED/); });
