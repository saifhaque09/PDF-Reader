import type { ChatAuthorizationService } from '../authorization/chat-authorization';

export type AttachmentStatus = 'UPLOADING' | 'SCANNING' | 'AVAILABLE' | 'BLOCKED' | 'FAILED' | 'QUARANTINED' | 'DELETED';
export type IncomingFile = { originalFileName: string; mimeType: string; fileSize: number; checksum?: string; bytes: Uint8Array };
export type StoredAttachment = { id: string; messageId: string; originalFileName: string; fileName: string; mimeType: string; fileSize: number; storageKey: string; status: AttachmentStatus; uploadedBy: string };

const ALLOWED: Record<string, readonly string[]> = {
  '.pdf': ['application/pdf'], '.jpg': ['image/jpeg'], '.jpeg': ['image/jpeg'], '.png': ['image/png'],
  '.doc': ['application/msword'], '.docx': ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
  '.xls': ['application/vnd.ms-excel'], '.xlsx': ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
  '.csv': ['text/csv', 'application/csv'],
};

export interface AttachmentScanner { scan(file: IncomingFile): Promise<'CLEAN' | 'INFECTED' | 'ERROR'>; }
export interface SecureStorage { put(storageKey: string, bytes: Uint8Array, metadata: { mimeType: string; size: number }): Promise<void>; quarantine(storageKey: string, bytes: Uint8Array): Promise<void>; }
export interface AttachmentRepository { create(input: Omit<StoredAttachment, 'id'>): Promise<StoredAttachment>; updateStatus(id: string, status: AttachmentStatus): Promise<StoredAttachment>; }

export class AttachmentService {
  constructor(private readonly auth: ChatAuthorizationService, private readonly scanner: AttachmentScanner, private readonly storage: SecureStorage, private readonly repository: AttachmentRepository, private readonly maxBytes = 25 * 1024 * 1024) {}

  async upload(userId: string, messageId: string, conversationId: string, file: IncomingFile) {
    if (!await this.auth.canSendMessage(userId, conversationId)) throw new Error('ATTACHMENT_UPLOAD_NOT_AUTHORIZED');
    const extension = `.${file.originalFileName.split('.').pop()?.toLowerCase() ?? ''}`;
    if (!ALLOWED[extension]?.includes(file.mimeType)) throw new Error('ATTACHMENT_TYPE_NOT_ALLOWED');
    if (file.fileSize > this.maxBytes || file.fileSize !== file.bytes.byteLength) throw new Error('ATTACHMENT_SIZE_NOT_ALLOWED');
    const storageKey = `quarantine/${crypto.randomUUID()}`;
    let status: AttachmentStatus = 'SCANNING';
    try {
      const scan = await this.scanner.scan(file);
      if (scan === 'INFECTED') { await this.storage.quarantine(storageKey, file.bytes); status = 'BLOCKED'; }
      else if (scan === 'ERROR') { await this.storage.quarantine(storageKey, file.bytes); status = 'QUARANTINED'; }
      else { await this.storage.put(storageKey, file.bytes, { mimeType: file.mimeType, size: file.fileSize }); status = 'AVAILABLE'; }
    } catch { status = 'FAILED'; }
    const record = await this.repository.create({ messageId, originalFileName: file.originalFileName, fileName: file.originalFileName, mimeType: file.mimeType, fileSize: file.fileSize, storageKey, status, uploadedBy: userId });
    if (status !== 'AVAILABLE') throw new Error(`ATTACHMENT_${status}`);
    return record;
  }
}
