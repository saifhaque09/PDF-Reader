import { strict as assert } from 'node:assert';
import test from 'node:test';
import { AttachmentService } from './attachment.service';

const file = (name = 'report.pdf', mimeType = 'application/pdf', size = 4) => ({ originalFileName: name, mimeType, fileSize: size, bytes: new Uint8Array(size) });
const setup = (scan: 'CLEAN' | 'INFECTED' | 'ERROR' = 'CLEAN', canSend = true) => { const records: any[] = []; const auth = { canSendMessage: async () => canSend } as any; const scanner = { scan: async () => scan }; const storage = { put: async () => {}, quarantine: async () => {} }; const repository = { create: async (input: any) => { const record = { id: 'a1', ...input }; records.push(record); return record; }, updateStatus: async () => null }; return { service: new AttachmentService(auth, scanner, storage, repository), records, auth, scanner, storage, repository }; };

test('valid file is available after a clean scan', async () => { const { service } = setup(); const result = await service.upload('u1', 'm1', 'c1', file()); assert.equal(result.status, 'AVAILABLE'); });
test('invalid type and oversized files are rejected before scanning', async () => { const { service } = setup(); await assert.rejects(() => service.upload('u1', 'm1', 'c1', file('script.exe', 'application/octet-stream')), /TYPE_NOT_ALLOWED/); await assert.rejects(() => service.upload('u1', 'm1', 'c1', file('large.pdf', 'application/pdf', 30 * 1024 * 1024)), /SIZE_NOT_ALLOWED/); });
test('failed scans produce quarantine or blocked statuses', async () => { const infected = setup('INFECTED'); await assert.rejects(() => infected.service.upload('u1', 'm1', 'c1', file()), /ATTACHMENT_BLOCKED/); const failed = setup('ERROR'); await assert.rejects(() => failed.service.upload('u1', 'm1', 'c1', file()), /ATTACHMENT_QUARANTINED/); });
test('storage failures create a failed record', async () => { const state = setup(); const service = new AttachmentService(state.auth, state.scanner, { put: async () => { throw new Error('storage'); }, quarantine: async () => {} }, state.repository); await assert.rejects(() => service.upload('u1', 'm1', 'c1', file()), /ATTACHMENT_FAILED/); });
test('unauthorized users cannot upload', async () => { const { service } = setup('CLEAN', false); await assert.rejects(() => service.upload('u1', 'm1', 'c1', file()), /NOT_AUTHORIZED/); });
