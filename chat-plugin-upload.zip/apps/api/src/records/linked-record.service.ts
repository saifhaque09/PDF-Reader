import type { IdentityProvider } from '../identity/identity-provider';

export type LinkedRecordType = 'TAX_RETURN' | 'DOCUMENT_REQUEST' | 'PAYROLL' | 'TASK' | 'ENGAGEMENT' | 'PAYMENT' | 'DEADLINE' | 'FINANCIAL_ACCOUNTING';
export type LinkedRecord = { conversationId: string; clientId: string; recordType: LinkedRecordType; recordId: string };
export interface LinkedRecordRepository { getLink(conversationId: string): Promise<LinkedRecord | null>; }
export interface AccountingRecordAccess { canAccessRecord(userId: string, recordType: LinkedRecordType, recordId: string, clientId: string): Promise<boolean>; createRecordUrl(recordType: LinkedRecordType, recordId: string): string; }

export class LinkedRecordService {
  constructor(private readonly identity: IdentityProvider, private readonly links: LinkedRecordRepository, private readonly records: AccountingRecordAccess) {}

  async getForConversation(userId: string, conversationId: string) {
    const link = await this.links.getLink(conversationId);
    if (!link || !await this.identity.canAccessClient(userId, link.clientId) || !await this.records.canAccessRecord(userId, link.recordType, link.recordId, link.clientId)) throw new Error('LINKED_RECORD_ACCESS_DENIED');
    return { type: link.recordType, id: link.recordId };
  }

  async open(userId: string, conversationId: string) {
    const record = await this.getForConversation(userId, conversationId);
    return { ...record, url: this.records.createRecordUrl(record.type, record.id) };
  }
}
