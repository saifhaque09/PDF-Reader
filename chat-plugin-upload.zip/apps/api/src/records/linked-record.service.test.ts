import { strict as assert } from 'node:assert';
import test from 'node:test';
import { LinkedRecordService } from './linked-record.service';

const setup = (allowed = true, clientAllowed = true) => { const identity = { canAccessClient: async () => clientAllowed } as any; const links = { getLink: async () => ({ conversationId: 'c1', clientId: 'client-1', recordType: 'TAX_RETURN' as const, recordId: 'return-1' }) }; const records = { canAccessRecord: async () => allowed, createRecordUrl: (type: string, id: string) => `/portal/records/${type}/${id}` }; return new LinkedRecordService(identity, links, records); };

test('authorized user can view and open linked record', async () => { const result = await setup().open('u1', 'c1'); assert.equal(result.type, 'TAX_RETURN'); assert.equal(result.url, '/portal/records/TAX_RETURN/return-1'); });
test('record permission revocation is respected immediately', async () => { await assert.rejects(() => setup(false).open('u1', 'c1'), /ACCESS_DENIED/); await assert.rejects(() => setup(true, false).getForConversation('u1', 'c1'), /ACCESS_DENIED/); });
test('missing link is denied', async () => { const service = new LinkedRecordService({ canAccessClient: async () => true } as any, { getLink: async () => null }, {} as any); await assert.rejects(() => service.getForConversation('u1', 'c1'), /ACCESS_DENIED/); });
