import { Body, CanActivate, Controller, ExecutionContext, Get, Injectable, Module, Param, Post, Req, UnauthorizedException, UseGuards } from '@nestjs/common';
import type { IncomingMessage } from 'node:http';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { FileInterceptor } from '@nestjs/platform-express';
import { UploadedFile, UseInterceptors } from '@nestjs/common';

export type PortalIdentity = { portalUserId: string; name?: string; email?: string };
type DevMessage = { id: string; senderName: string; messageText: string; messageHtml?: string; createdAt: string; read: boolean };
type DevConversation = { id: string; type: 'ONE_TO_ONE' | 'GROUP'; name: string; clientName: string; participants: string[]; messages: DevMessage[]; linkedRecord?: { type: string; id: string } };
const devConversations = new Map<string, DevConversation>();

@Injectable()
export class OidcJwtGuard implements CanActivate {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest<IncomingMessage>();
    const header = request.headers.authorization;
    if (process.env.IDENTITY_PROVIDER === 'local' && process.env.DEV_AUTH === 'true') {
      const devUserId = request.headers['x-dev-user-id'] ?? 'user-owner';
      if (typeof devUserId !== 'string' || !['user-owner', 'user-client', 'user-team', 'user-inactive'].includes(devUserId)) throw new UnauthorizedException();
      (request as IncomingMessage & { chatUserId?: string }).chatUserId = devUserId;
      return true;
    }
    const issuer = process.env.OIDC_ISSUER_URL;
    const audience = process.env.OIDC_AUDIENCE;
    const jwksUri = process.env.OIDC_JWKS_URI;
    if (!header?.startsWith('Bearer ') || !issuer || !audience || !jwksUri) throw new UnauthorizedException();
    try {
      await jwtVerify(header.slice(7), createRemoteJWKSet(new URL(jwksUri)), { issuer, audience });
    } catch { throw new UnauthorizedException(); }
    return true;
  }
}

@Controller('health')
class HealthController { @Get() get() { return { status: 'ok', service: 'chat-api' }; } }

@Controller('chat/inbox')
class InboxController {
  @Get()
  @UseGuards(OidcJwtGuard)
  getInbox(@Req() request: IncomingMessage) {
    return { user: (request as IncomingMessage & { chatUserId?: string }).chatUserId ?? null, conversations: [] };
  }


}

@Controller('chat/contacts')
class ContactsController {
  @Get()
  @UseGuards(OidcJwtGuard)
  getContacts() {
    return { contacts: [{ id: 'user-client', displayName: 'Sarah Carter', organization: 'ABC Corporation', category: 'CLIENT', participantType: 'Client employee', online: true }, { id: 'user-team', displayName: 'Michael Thompson', organization: 'Internal Team', category: 'INTERNAL', participantType: 'Accountant', online: false, lastSeen: 'recently' }, { id: 'user-owner', displayName: 'Alex Morgan', organization: 'Internal Team', category: 'INTERNAL', participantType: 'Super Admin', online: true }] };
  }
}

@Controller('chat/conversations')
class ConversationController {
  @Post()
  @UseGuards(OidcJwtGuard)
  createConversation(@Body() body: { type?: string; name?: string; clientId?: string; participantIds?: string[]; linkedRecordType?: string; linkedRecordId?: string }) {
    if (!body.clientId || !Array.isArray(body.participantIds) || body.participantIds.length === 0 || !['ONE_TO_ONE', 'GROUP'].includes(body.type ?? '') || (body.type === 'GROUP' && !body.name?.trim())) throw new UnauthorizedException('Invalid conversation setup');
    const id = `dev-${crypto.randomUUID()}`;
    const conversation = { id, type: body.type as 'ONE_TO_ONE' | 'GROUP', participantType: (body as { participantType?: string }).participantType, name: body.name?.trim() || 'New conversation', clientName: body.clientId, participants: body.participantIds, messages: [], ...(body.linkedRecordType && body.linkedRecordId ? { linkedRecord: { type: body.linkedRecordType, id: body.linkedRecordId } } : {}) };
    devConversations.set(id, conversation);
    return conversation;
  }

  @Get(':conversationId')
  @UseGuards(OidcJwtGuard)
  getConversation(@Param('conversationId') conversationId: string) {
    let conversation = devConversations.get(conversationId);
    if (!conversation && conversationId.startsWith('dev-')) {
      conversation = { id: conversationId, type: 'ONE_TO_ONE', name: 'New conversation', clientName: 'client-abc', participants: ['user-owner'], messages: [] };
      devConversations.set(conversationId, conversation);
    }
    if (!conversation) throw new UnauthorizedException('Conversation unavailable');
    return conversation;
  }

  @Post(':conversationId/messages')
  @UseGuards(OidcJwtGuard)
  addMessage(@Param('conversationId') conversationId: string, @Body() body: { messageText?: string }) {
    const conversation = devConversations.get(conversationId);
    if (!conversation || !body.messageText?.trim()) throw new UnauthorizedException('Invalid message');
    const safeHtml = typeof (body as { messageHtml?: string }).messageHtml === 'string' ? (body as { messageHtml: string }).messageHtml.replace(/<(?!\/?(b|i|u|br|img)\b)[^>]*>/gi, '').replace(/ on\w+=("[^"]*"|'[^']*')/gi, '') : undefined;
    const message = { id: `dev-message-${crypto.randomUUID()}`, senderName: 'Alex Morgan', messageText: body.messageText.trim(), messageHtml: safeHtml, createdAt: new Date().toISOString(), read: true };
    conversation.messages.push(message);
    return message;
  }

  @Post(':conversationId/attachments')
  @UseGuards(OidcJwtGuard)
  @UseInterceptors(FileInterceptor('file'))
  uploadAttachment(@Param('conversationId') conversationId: string, @UploadedFile() file?: { originalname: string; mimetype: string; size: number }) {
    if (!file) throw new UnauthorizedException('File is required');
    const allowed = /\.(pdf|jpg|jpeg|png|doc|docx|xls|xlsx|csv)$/i.test(file.originalname);
    if (!allowed || file.size > 25 * 1024 * 1024) throw new UnauthorizedException('File type or size is not allowed');
    return { id: `dev-attachment-${crypto.randomUUID()}`, conversationId, originalFileName: file.originalname, mimeType: file.mimetype, status: 'SCANNING' };
  }
}

@Module({ controllers: [HealthController, InboxController, ContactsController, ConversationController], providers: [OidcJwtGuard] })
export class AppModule {}
