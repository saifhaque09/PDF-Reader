import type { IdentityProvider } from '../identity/identity-provider';

export type GroupEventType = 'GROUP_CREATED' | 'PARTICIPANT_ADDED' | 'PARTICIPANT_REMOVED' | 'PARTICIPANT_LEFT' | 'GROUP_NAME_CHANGED';
export type GroupParticipant = { userId: string; role: 'OWNER' | 'ADMIN' | 'MEMBER'; status: 'ACTIVE' | 'LEFT' };
export type GroupConversation = { id: string; type: 'GROUP'; name: string; clientId: string; linkedRecordType?: string; linkedRecordId?: string; status: 'ACTIVE' | 'ARCHIVED'; participants: GroupParticipant[] };

export interface GroupRepository {
  createGroup(input: Omit<GroupConversation, 'id' | 'participants'>, participants: GroupParticipant[]): Promise<GroupConversation>;
  getGroup(id: string): Promise<GroupConversation | null>;
  addParticipant(groupId: string, participant: GroupParticipant): Promise<void>;
  setParticipantStatus(groupId: string, userId: string, status: 'ACTIVE' | 'LEFT'): Promise<void>;
  updateName(groupId: string, name: string): Promise<void>;
  addEvent(groupId: string, type: GroupEventType, actorId: string, subjectUserId?: string, metadata?: Record<string, string>): Promise<void>;
}

export class GroupConversationService {
  constructor(private readonly identity: IdentityProvider, private readonly repository: GroupRepository) {}

  async createGroup(actorId: string, input: { name: string; clientId: string; linkedRecordType?: string; linkedRecordId?: string }, participantIds: string[]) {
    const actor = await this.identity.getUser(actorId);
    if (!actor?.active || !input.name.trim() || !await this.identity.canAccessClient(actorId, input.clientId) || !await this.identity.hasPermission(actorId, 'chat.groups.create', input.clientId)) throw new Error('GROUP_CREATE_NOT_AUTHORIZED');
    const ids = [...new Set([actorId, ...participantIds])];
    const authorized = await Promise.all(ids.map(async (userId) => {
      const user = await this.identity.getUser(userId);
      return !!user?.active && await this.identity.canAccessClient(userId, input.clientId) && await this.identity.hasPermission(actorId, 'chat.groups.create', input.clientId);
    }));
    if (authorized.some((allowed) => !allowed)) throw new Error('PARTICIPANT_NOT_AUTHORIZED');
    const group = await this.repository.createGroup({ type: 'GROUP', name: input.name.trim(), clientId: input.clientId, linkedRecordType: input.linkedRecordType, linkedRecordId: input.linkedRecordId, status: 'ACTIVE' }, ids.map((userId) => ({ userId, role: userId === actorId ? 'OWNER' : 'MEMBER', status: 'ACTIVE' })));
    await this.repository.addEvent(group.id, 'GROUP_CREATED', actorId, undefined, { participantCount: String(ids.length) });
    return group;
  }

  async addParticipant(actorId: string, groupId: string, targetUserId: string) {
    const group = await this.requireManager(actorId, groupId);
    const target = await this.identity.getUser(targetUserId);
    if (!target?.active || !await this.identity.canAccessClient(targetUserId, group.clientId)) throw new Error('PARTICIPANT_NOT_AUTHORIZED');
    if (!await this.identity.hasPermission(actorId, 'chat.groups.manage', group.clientId)) throw new Error('GROUP_MANAGE_NOT_AUTHORIZED');
    await this.repository.addParticipant(groupId, { userId: targetUserId, role: 'MEMBER', status: 'ACTIVE' });
    await this.repository.addEvent(groupId, 'PARTICIPANT_ADDED', actorId, targetUserId);
  }

  async removeParticipant(actorId: string, groupId: string, targetUserId: string) {
    const group = await this.requireManager(actorId, groupId);
    if (targetUserId === actorId && group.participants.find((p) => p.userId === actorId)?.role === 'OWNER') throw new Error('OWNER_MUST_TRANSFER');
    if (!await this.identity.hasPermission(actorId, 'chat.groups.manage', group.clientId)) throw new Error('GROUP_MANAGE_NOT_AUTHORIZED');
    await this.repository.setParticipantStatus(groupId, targetUserId, 'LEFT');
    await this.repository.addEvent(groupId, 'PARTICIPANT_REMOVED', actorId, targetUserId);
  }

  async leaveGroup(actorId: string, groupId: string) {
    const group = await this.repository.getGroup(groupId);
    if (!group || !group.participants.some((p) => p.userId === actorId && p.status === 'ACTIVE')) throw new Error('GROUP_ACCESS_DENIED');
    if (group.participants.find((p) => p.userId === actorId)?.role === 'OWNER') throw new Error('OWNER_MUST_TRANSFER');
    await this.repository.setParticipantStatus(groupId, actorId, 'LEFT');
    await this.repository.addEvent(groupId, 'PARTICIPANT_LEFT', actorId, actorId);
  }

  async changeName(actorId: string, groupId: string, name: string) {
    const group = await this.requireManager(actorId, groupId);
    if (!name.trim() || !await this.identity.hasPermission(actorId, 'chat.groups.manage', group.clientId)) throw new Error('GROUP_MANAGE_NOT_AUTHORIZED');
    await this.repository.updateName(groupId, name.trim());
    await this.repository.addEvent(groupId, 'GROUP_NAME_CHANGED', actorId, undefined, { name: name.trim() });
  }

  private async requireManager(actorId: string, groupId: string) {
    const group = await this.repository.getGroup(groupId);
    const member = group?.participants.find((p) => p.userId === actorId && p.status === 'ACTIVE');
    if (!group || !member || !['OWNER', 'ADMIN'].includes(member.role) || !await this.identity.canAccessClient(actorId, group.clientId)) throw new Error('GROUP_ACCESS_DENIED');
    return group;
  }
}
