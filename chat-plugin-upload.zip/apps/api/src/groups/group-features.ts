import type { GroupConversation, GroupParticipant } from './group-conversation.service';

export type GroupNotificationPreference = 'ALL_MESSAGES' | 'MENTIONS_ONLY' | 'MUTED';
export type ParticipantReadState = { userId: string; readAt: string | null };

export function resolveMentions(text: string, group: GroupConversation, actorId: string) {
  const actor = group.participants.find((participant) => participant.userId === actorId && participant.status === 'ACTIVE');
  if (!actor) throw new Error('GROUP_ACCESS_DENIED');
  const requested = [...text.matchAll(/@([A-Za-z0-9_-]+)/g)].map((match) => match[1]);
  const authorized = requested.filter((userId) => group.participants.some((participant) => participant.userId === userId && participant.status === 'ACTIVE'));
  const invalid = requested.filter((userId) => !authorized.includes(userId));
  if (invalid.length) throw new Error('MENTION_TARGET_NOT_AUTHORIZED');
  return [...new Set(authorized)];
}

export function canNotify(preference: GroupNotificationPreference, mentioned: boolean) {
  return preference === 'ALL_MESSAGES' || (preference === 'MENTIONS_ONLY' && mentioned);
}

export function getReadByParticipants(group: GroupConversation, reads: ParticipantReadState[]) {
  return group.participants.filter((participant) => participant.status === 'ACTIVE').map((participant) => ({
    userId: participant.userId,
    readAt: reads.find((read) => read.userId === participant.userId)?.readAt ?? null,
  }));
}

export function activeParticipants(group: GroupConversation): GroupParticipant[] {
  return group.participants.filter((participant) => participant.status === 'ACTIVE');
}
