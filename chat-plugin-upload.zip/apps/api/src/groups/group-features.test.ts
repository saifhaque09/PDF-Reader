import { strict as assert } from 'node:assert';
import test from 'node:test';
import { canNotify, getReadByParticipants, resolveMentions } from './group-features';

const group = { id: 'g1', type: 'GROUP' as const, name: 'Team', clientId: 'client-1', status: 'ACTIVE' as const, participants: [{ userId: 'owner', role: 'OWNER' as const, status: 'ACTIVE' as const }, { userId: 'member', role: 'MEMBER' as const, status: 'ACTIVE' as const }, { userId: 'left', role: 'MEMBER' as const, status: 'LEFT' as const }] };

test('valid mention resolves only to an active participant', () => assert.deepEqual(resolveMentions('Hello @member', group, 'owner'), ['member']));
test('invalid or unauthorized mention is rejected', () => { assert.throws(() => resolveMentions('Hello @outsider', group, 'owner'), /MENTION_TARGET_NOT_AUTHORIZED/); assert.throws(() => resolveMentions('Hello @member', group, 'outsider'), /GROUP_ACCESS_DENIED/); });
test('notification preferences apply to ordinary messages and mentions', () => { assert.equal(canNotify('ALL_MESSAGES', false), true); assert.equal(canNotify('MENTIONS_ONLY', false), false); assert.equal(canNotify('MENTIONS_ONLY', true), true); assert.equal(canNotify('MUTED', true), false); });
test('read-by-participant excludes users who left', () => assert.deepEqual(getReadByParticipants(group, [{ userId: 'owner', readAt: '2026-08-23T12:00:00Z' }]), [{ userId: 'owner', readAt: '2026-08-23T12:00:00Z' }, { userId: 'member', readAt: null }]));
