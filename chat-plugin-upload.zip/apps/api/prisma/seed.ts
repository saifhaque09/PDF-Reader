// Development seed reference. Production identity data must come from the configured identity provider.
export const localDevelopmentSeed = {
  client: { id: 'client-abc', name: 'ABC Corporation' },
  users: ['user-owner', 'user-client', 'user-team', 'user-inactive'],
};
