# Database foundation

This schema is the migration input for the Chat-owned PostgreSQL database. No migration has been executed in this scaffold.
