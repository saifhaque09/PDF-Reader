import type { FormEvent } from 'react';

export type Participant = { userId: string; displayName: string; role: 'OWNER' | 'ADMIN' | 'MEMBER'; status: 'ACTIVE' | 'LEFT'; online?: boolean };

export function GroupParticipants({ participants, canManage, onAdd, onRemove, onLeave }: { participants: Participant[]; canManage: boolean; onAdd: () => void; onRemove: (userId: string) => void; onLeave: () => void }) {
  const submit = (event: FormEvent) => { event.preventDefault(); onAdd(); };
  return <aside className="participant-panel" aria-labelledby="participants-title"><div className="participant-heading"><h2 id="participants-title">Participants</h2>{canManage && <button type="button" onClick={onAdd}>Add participant</button>}</div><ul>{participants.filter((participant) => participant.status === 'ACTIVE').map((participant) => <li key={participant.userId}><span className={`presence ${participant.online ? 'online' : 'offline'}`} aria-label={participant.online ? 'Online' : 'Offline'} /><span><strong>{participant.displayName}</strong><small>{participant.role}</small></span>{canManage && participant.role !== 'OWNER' && <button type="button" onClick={() => onRemove(participant.userId)} aria-label={`Remove ${participant.displayName}`}>Remove</button>}</li>)}</ul><form onSubmit={submit}><button type="submit" className="leave-button">Leave group</button></form></aside>;
}
