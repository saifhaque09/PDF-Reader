import { useEffect, useState } from 'react';

type Notification = { id: string; type: string; message?: string; conversationId: string };
export function NotificationIndicator() {
  const [items, setItems] = useState<Notification[]>([]);
  useEffect(() => { void fetch('/api/chat/notifications/unread').then((response) => response.ok ? response.json() : { notifications: [] }).then((payload: { notifications: Notification[] }) => setItems(payload.notifications)).catch(() => setItems([])); }, []);
  return <button type="button" className="notification-indicator" aria-label={`${items.length} unread notifications`}><span aria-hidden="true">◔</span>{items.length > 0 && <span className="notification-badge">{items.length}</span>}</button>;
}
