import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';
import { ConversationWindow } from './conversation';
import { AttachmentViewer } from './attachment-viewer';
import { ConversationSetup } from './conversation-setup';
import { ContactsPage } from './contacts';

/* The Contacts page is the Chat entry point. */
/*
  const [conversations, setConversations] = useState<InboxConversation[]>([]);
  const [query, setQuery] = useState('');
  const [state, setState] = useState<'loading' | 'ready' | 'error' | 'unauthorized'>('loading');

  const loadInbox = async () => {
    setState('loading');
    try {
      const response = await fetch('/api/chat/inbox');
      if (response.status === 401 || response.status === 403) { setState('unauthorized'); return; }
      if (!response.ok) throw new Error('Inbox request failed');
      const payload = await response.json() as { conversations: InboxConversation[] };
      setConversations(payload.conversations);
      setState('ready');
    } catch { setState('error'); }
  };

  useEffect(() => { void loadInbox(); }, []);
  const visible = useMemo(() => conversations.filter((item) => `${item.name} ${item.clientName ?? ''} ${item.lastMessage ?? ''}`.toLowerCase().includes(query.toLowerCase())), [conversations, query]);

  return <main className="chat-shell" aria-labelledby="chat-title">
    <header className="page-header"><div><p className="eyebrow">Workspace</p><h1 id="chat-title">Chat</h1></div><div><NotificationIndicator /><button className="secondary-button" type="button" onClick={() => window.location.assign('/chat/contacts')}>Contacts</button><button className="primary-button" type="button" onClick={() => window.location.assign('/chat/new')}>＋ New conversation</button></div></header>
    <label className="search-label" htmlFor="conversation-search">Search conversations</label>
    <input id="conversation-search" className="search-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search conversations..." />
    {state === 'loading' && <section className="state-card" aria-live="polite"><span className="spinner" aria-hidden="true" />Loading conversations...</section>}
    {state === 'error' && <section className="state-card error" role="alert"><h2>Unable to load conversations</h2><p>Please try again.</p><button type="button" onClick={() => void loadInbox()}>Retry</button></section>}
    {state === 'unauthorized' && <section className="state-card" role="status"><h2>Access unavailable</h2><p>You no longer have access to Chat.</p></section>}
    {state === 'ready' && visible.length === 0 && <section className="state-card" aria-live="polite"><h2>No conversations yet</h2><p>Authorized conversations will appear here.</p></section>}
    {state === 'ready' && visible.length > 0 && <section className="conversation-list" aria-label="Authorized conversations">{visible.map((item) => <button className="conversation-row" key={item.id} type="button" onClick={() => window.location.assign(`/chat/conversations/${item.id}`)}><span className={`presence ${item.online ? 'online' : 'offline'}`} aria-label={item.online ? 'Online' : 'Offline'} /><span className="conversation-copy"><strong>{item.name}</strong><span>{item.clientName ?? 'No client linked'}</span><small>{item.lastMessage ?? 'No messages yet'}{item.updatedAt ? ` · ${new Date(item.updatedAt).toLocaleString()}` : ''}</small></span>{item.pinned && <span aria-label="Pinned">📌</span>}{item.muted && <span aria-label="Muted">🔕</span>}{item.unreadCount > 0 && <span className="unread" aria-label={`${item.unreadCount} unread`}>{item.unreadCount}</span>}</button>)}</section>}
  </main>;
}
*/

const match = window.location.pathname.match(/^\/chat\/conversations\/([^/]+)/);
const attachmentMatch = window.location.pathname.match(/^\/chat\/attachments\/([^/]+)/);
const newConversation = window.location.pathname === '/chat/new';
const contacts = window.location.pathname === '/chat/contacts';
createRoot(document.getElementById('root')!).render(<StrictMode>{attachmentMatch ? <AttachmentViewer attachmentId={decodeURIComponent(attachmentMatch[1])} /> : match ? <ConversationWindow conversationId={decodeURIComponent(match[1])} /> : newConversation ? <ConversationSetup /> : <ContactsPage />}</StrictMode>);
