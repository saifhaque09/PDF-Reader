import { FormEvent, useEffect, useState } from 'react';

export type Message = { id: string; senderName: string; messageText: string; messageHtml?: string; createdAt: string; read: boolean };
export type ConversationData = { id: string; name: string; type?: 'ONE_TO_ONE' | 'GROUP'; participantType?: string; clientName?: string; linkedRecord?: { type: string; id: string }; participants: string[]; messages: Message[]; nextCursor?: string };

export function ConversationWindow({ conversationId }: { conversationId: string }) {
  const [data, setData] = useState<ConversationData | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'error' | 'revoked'>('loading');
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [showActions, setShowActions] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [muted, setMuted] = useState(false);
  const [searchMode, setSearchMode] = useState<'TEXT' | 'RECORD_ID' | 'RECORD_TYPE'>('TEXT');
  const [searchQuery, setSearchQuery] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [html, setHtml] = useState('');
  const [uploading, setUploading] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const emojis = ['😀', '🙂', '😂', '😍', '👍', '👏', '🎉', '✅', '🙏', '❤️'];

  const load = async () => {
    setState('loading');
    try {
      const response = await fetch(`/api/chat/conversations/${encodeURIComponent(conversationId)}?limit=50`);
      if (response.status === 401 || response.status === 403) { setState('revoked'); return; }
      if (!response.ok) throw new Error();
      setData(await response.json() as ConversationData); setState('ready');
    } catch { setState('error'); }
  };
  useEffect(() => { void load(); }, [conversationId]);

  const send = async (event: FormEvent) => {
    event.preventDefault(); const messageText = text.trim();
    if (!messageText || sending) return;
    setSending(true); setSendError(null);
    try {
      const response = await fetch(`/api/chat/conversations/${encodeURIComponent(conversationId)}/messages`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messageText, messageHtml: html }) });
      if (response.status === 401 || response.status === 403) { setState('revoked'); return; }
      if (!response.ok) { const details = await response.text(); throw new Error(details || `Message failed (${response.status})`); }
      const message = await response.json() as Message;
      setData((current) => current ? { ...current, messages: [...current.messages, message] } : current); setText(''); setHtml('');
    } catch (error) { setSendError(error instanceof Error ? error.message : 'Unable to send message'); } finally { setSending(false); }
  };

  if (state === 'loading') return <section className="state-card"><span className="spinner" aria-hidden="true" />Loading conversation...</section>;
  if (state === 'revoked') return <section className="state-card" role="status"><h2>Access revoked</h2><p>You no longer have access to this conversation.</p></section>;
  if (state === 'error') return <section className="state-card error" role="alert"><h2>Unable to load conversation</h2><button type="button" onClick={() => void load()}>Retry</button></section>;
  if (!data) return null;
  const unreadCount = data.messages.filter((message) => !message.read).length;
  const filteredMessages = data.messages.filter((message) => { const query = searchQuery.trim().toLowerCase(); if (!query) return true; if (searchMode === 'RECORD_ID') return data.linkedRecord?.id.toLowerCase().includes(query) ?? false; if (searchMode === 'RECORD_TYPE') return data.linkedRecord?.type.toLowerCase().includes(query) ?? false; return message.messageText.toLowerCase().includes(query) || message.messageHtml?.toLowerCase().includes(query) === true; });
  const openRecord = async () => { if (!data.linkedRecord) return; const response = await fetch(`/api/chat/conversations/${encodeURIComponent(data.id)}/linked-record`); if (response.status === 401 || response.status === 403) { setState('revoked'); return; } if (response.ok) { const result = await response.json() as { url: string }; window.location.assign(result.url); } else setState('error'); };
  const upload = async (file: File) => { setUploading(true); try { const form = new FormData(); form.append('file', file); const response = await fetch(`/api/chat/conversations/${encodeURIComponent(conversationId)}/attachments`, { method: 'POST', body: form }); if (!response.ok) throw new Error(); } catch { setState('error'); } finally { setUploading(false); } };
  const format = (command: 'bold' | 'italic' | 'underline') => { document.execCommand(command); setHtml(document.getElementById('message-input')?.innerHTML ?? ''); setText(document.getElementById('message-input')?.textContent ?? ''); };
  return <main className="conversation-shell" aria-labelledby="conversation-title">
    <header className="conversation-header"><div><button className="back-button" type="button" onClick={() => window.location.assign('/chat')}>← Back to Chat</button><h1 id="conversation-title">{data.name}</h1><p>{data.clientName ?? 'No client linked'} · {data.participants.length} participant{data.participants.length === 1 ? '' : 's'}</p>{data.linkedRecord && <p className="record-link">Linked record: {data.linkedRecord.type} · {data.linkedRecord.id} <button type="button" onClick={() => void openRecord()}>View record</button></p>}</div><div className="conversation-header-actions"><button type="button" className="secondary-button" onClick={() => window.location.assign('/chat/new')}>＋ New Conversation</button><button type="button" className="secondary-button" onClick={() => window.location.assign('/chat/contacts')}>Close</button><span className="conversation-notification" aria-label={`${unreadCount} unread messages`} title={`${unreadCount} unread messages`}>🔔{unreadCount > 0 && <b>{unreadCount}</b>}</span><div className="actions-wrap"><button type="button" className="secondary-button" aria-expanded={showActions} onClick={() => setShowActions((visible) => !visible)}>Conversation actions ▾</button>{showActions && <div className="actions-menu" role="menu"><button type="button" role="menuitem" onClick={() => setPinned((value) => !value)}>{pinned ? 'Unpin conversation' : 'Pin conversation'}</button><button type="button" role="menuitem" onClick={() => setMuted((value) => !value)}>{muted ? 'Unmute conversation' : 'Mute conversation'}</button><button type="button" role="menuitem" onClick={() => { void navigator.clipboard?.writeText(window.location.href); setShowActions(false); }}>Copy conversation link</button><button type="button" role="menuitem" onClick={() => window.location.assign('/chat')}>Archive conversation</button></div>}</div></div></header>
    <div className="conversation-search"><label htmlFor="conversation-search-mode">Search</label><select id="conversation-search-mode" value={searchMode} onChange={(event) => setSearchMode(event.target.value as 'TEXT' | 'RECORD_ID' | 'RECORD_TYPE')}><option value="TEXT">Message text</option><option value="RECORD_ID">Record ID</option><option value="RECORD_TYPE">Record Type</option></select><input aria-label={searchMode === 'TEXT' ? 'Search message text' : searchMode === 'RECORD_ID' ? 'Search Record ID' : 'Search Record Type'} value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} placeholder={searchMode === 'TEXT' ? 'Search messages...' : searchMode === 'RECORD_ID' ? 'Search Record ID...' : 'Search Record Type...'} /></div><section className="message-history" aria-label="Message history">{data.messages.length === 0 ? <div className="empty-messages"><h2>No messages yet</h2><p>Start the conversation below.</p></div> : filteredMessages.length === 0 ? <div className="empty-messages"><h2>No matches found</h2><p>Try another search.</p></div> : filteredMessages.map((message) => <article className={`message ${message.read ? 'read' : 'unread-message'}`} key={message.id}><strong>{message.senderName}</strong><time dateTime={message.createdAt}>{new Date(message.createdAt).toLocaleString()}</time>{message.messageHtml ? <div className="message-content" dangerouslySetInnerHTML={{ __html: message.messageHtml }} /> : <p>{message.messageText}</p>}<small>{message.read ? 'Read' : 'Unread'} · {data.type === 'GROUP' ? 'Group' : 'One-to-one'}</small></article>)}</section>
    <form className="composer" onSubmit={send}><label htmlFor="message-input">Message</label><div className="format-toolbar" role="toolbar" aria-label="Text formatting"><button type="button" onClick={() => format('bold')}><strong>B</strong></button><button type="button" onClick={() => format('italic')}><em>I</em></button><button type="button" onClick={() => format('underline')}><u>U</u></button><label className="file-button">📎 Attach file<input type="file" hidden accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx,.csv" disabled={uploading} onChange={(event) => { const file = event.target.files?.[0]; if (file) void upload(file); event.currentTarget.value = ''; }} /></label></div><div id="message-input" className="rich-editor" contentEditable={!sending} role="textbox" aria-multiline="true" data-placeholder="Write a message..." onPaste={(event) => { const itemImage = Array.from(event.clipboardData.items).find((item) => item.type.startsWith('image/')); const fileImage = Array.from(event.clipboardData.files).find((file) => file.type.startsWith('image/')); const file = itemImage?.getAsFile() ?? fileImage; if (file) { event.preventDefault(); const reader = new FileReader(); reader.onload = () => { const selection = window.getSelection(); if (!selection?.rangeCount) return; const image = document.createElement('img'); image.src = String(reader.result); image.alt = 'Pasted image'; image.style.maxWidth = '100%'; const range = selection.getRangeAt(0); range.deleteContents(); range.insertNode(image); range.collapse(false); selection.removeAllRanges(); selection.addRange(range); setText((current) => `${current}[image]`); setHtml(document.getElementById('message-input')?.innerHTML ?? ''); }; reader.readAsDataURL(file); } }} onInput={(event) => { setText(event.currentTarget.textContent ?? ''); setHtml(event.currentTarget.innerHTML); }} />{sendError && <p className="form-error" role="alert">{sendError}<button type="button" onClick={() => setSendError(null)}>Dismiss</button></p>}<div className="composer-footer"><div className="composer-tools"><button type="button" className="emoji-button" aria-label="Add emoji" aria-expanded={showEmojiPicker} onClick={() => setShowEmojiPicker((visible) => !visible)}>😊</button>{showEmojiPicker && <div className="emoji-picker" role="group" aria-label="Emoji picker">{emojis.map((emoji) => <button type="button" key={emoji} className="emoji-choice" aria-label={`Add ${emoji}`} onClick={() => { setText((current) => `${current}${emoji}`); setShowEmojiPicker(false); }}>{emoji}</button>)}</div>}</div><span>{uploading ? 'Uploading file...' : text.trim() ? '' : 'Enter a message to send'}</span><button className="primary-button" type="submit" disabled={sending || (!text.trim() && !html)}>{sending ? 'Sending...' : 'Send message'}</button></div></form>
  </main>;
}
