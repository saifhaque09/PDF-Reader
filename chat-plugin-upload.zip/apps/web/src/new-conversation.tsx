export function NewConversationPlaceholder() {
  return <main className="chat-shell" aria-labelledby="new-conversation-title"><button className="back-button" type="button" onClick={() => window.location.assign('/chat')}>← Back to Chat</button><section className="state-card"><h1 id="new-conversation-title">New conversation</h1><p>Conversation setup is coming next.</p></section></main>;
}
