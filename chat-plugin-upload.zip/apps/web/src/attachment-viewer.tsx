import { useEffect, useState } from 'react';

type Attachment = { id: string; originalFileName: string; mimeType: string; fileSize: number; url: string; linkedRecordType?: string; linkedRecordId?: string; conversationId: string };

export function AttachmentViewer({ attachmentId }: { attachmentId: string }) {
  const [attachment, setAttachment] = useState<Attachment | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'error' | 'unauthorized' | 'unavailable'>('loading');
  useEffect(() => { void fetch(`/api/chat/attachments/${encodeURIComponent(attachmentId)}/access?mode=view`).then(async (response) => { if (response.status === 401 || response.status === 403) { setState('unauthorized'); return; } if (response.status === 404 || response.status === 410) { setState('unavailable'); return; } if (!response.ok) throw new Error(); setAttachment(await response.json() as Attachment); setState('ready'); }).catch(() => setState('error')); }, [attachmentId]);
  if (state === 'loading') return <section className="state-card"><span className="spinner" aria-hidden="true" />Loading file...</section>;
  if (state === 'unauthorized') return <section className="state-card"><h2>Access denied</h2><p>You are not authorized to view this file.</p></section>;
  if (state === 'unavailable') return <section className="state-card"><h2>File unavailable</h2><p>This file is blocked, deleted, or no longer available.</p></section>;
  if (state === 'error' || !attachment) return <section className="state-card error"><h2>Unable to load file</h2><button type="button" onClick={() => window.location.reload()}>Retry</button></section>;
  const isImage = attachment.mimeType.startsWith('image/');
  return <main className="viewer-shell" aria-labelledby="viewer-title"><header className="viewer-header"><div><button className="back-button" type="button" onClick={() => window.location.assign(`/chat/conversations/${attachment.conversationId}`)}>← View in conversation</button><h1 id="viewer-title">{attachment.originalFileName}</h1></div><a className="primary-button" href={`/api/chat/attachments/${encodeURIComponent(attachment.id)}/access?mode=download`} download>Download</a></header><section className="file-preview">{isImage ? <img src={attachment.url} alt={attachment.originalFileName} /> : attachment.mimeType === 'application/pdf' ? <iframe title={attachment.originalFileName} src={attachment.url} /> : <p>Preview is not available for this file type.</p>}</section><dl className="file-info"><dt>Type</dt><dd>{attachment.mimeType}</dd><dt>Size</dt><dd>{Math.round(attachment.fileSize / 1024)} KB</dd>{attachment.linkedRecordId && <><dt>Linked record</dt><dd><a href={`/records/${attachment.linkedRecordId}`}>{attachment.linkedRecordType ?? 'Accounting record'}</a></dd></>}</dl></main>;
}
