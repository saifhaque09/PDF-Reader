# Chat System Security Review

Date: 2026-08-23  
Scope: current standalone Chat plugin scaffold

## Executive summary

The project is not production-ready. It contains interfaces and unit-test examples for many controls, but most runtime controllers, persistence adapters, portal integration, storage adapters, and realtime infrastructure are not wired. The highest-risk issue is that the only implemented inbox controller returns a user identity from the client-controlled `x-portal-user-id` header after validating a JWT, without binding the request to the JWT subject or using that identity for authorization.

## Critical

### C1 — Client-controlled identity is exposed by the API

`apps/api/src/module.ts` returns `x-portal-user-id` directly. That header is supplied by the caller and is not derived from the verified JWT. Any endpoint that uses this value as the current user could permit impersonation and cross-user data access.

Remediation: attach the verified JWT subject/claims to the request context and obtain the current user only from that server-side context. Remove all trust in `x-portal-user-id`.

### C2 — Conversation and message endpoints are not implemented

The UI calls conversation, message, notification, attachment, and linked-record routes, but the API only exposes health and an empty protected inbox route. There is therefore no enforceable production access boundary for these operations yet.

Remediation: implement authenticated controllers that invoke the centralized authorization service before every read/write and return fail-closed responses.

## High

### H1 — OIDC/JWT validation is incomplete as an application identity flow

The guard validates issuer, audience, and JWKS signature, but discards the verified payload. It does not enforce a required subject, portal-user mapping, active status, token use, or claim-to-permission mapping.

Remediation: validate required claims, bind `sub` to the configured identity provider, reject inactive users, and pass a typed identity context into services.

### H2 — Authorization adapters are not wired to persistence or controllers

`ChatAuthorizationService` has the right conceptual checks, but no production repository/provider wiring is present. A database participant row must never be treated as sufficient access without current identity, active status, client access, and permission checks.

Remediation: dependency-inject real repository and identity-provider implementations and test every route at the HTTP boundary.

### H3 — Attachment access controls are service-only, not an enforced download boundary

The viewer service correctly re-checks authorization and issues five-minute signed URLs in its abstraction, but no controller or storage implementation is wired. The browser also calls an access route that does not currently exist.

Remediation: expose only an authenticated access endpoint, generate signed URLs only after authorization and availability checks, use short expiry and disposition controls, and ensure the storage bucket is private.

### H4 — Upload security is not operationally enforced

The upload service defines extension/MIME/size validation and scanner/storage interfaces, but no real malware scanner, content sniffing, archive-bomb protection, filename normalization, or upload endpoint is wired. MIME values supplied by the client must not be trusted.

Remediation: validate magic bytes server-side, normalize names, enforce quotas, scan before storage availability, quarantine failures, and prevent executable content from being served.

### H5 — No rate limiting or abuse controls

There is no rate limiting for authentication, inbox/search, message creation, uploads, signed URL issuance, or notification endpoints.

Remediation: add per-user/IP limits, upload quotas, message throttling, and monitoring before production.

### H6 — CSRF and session transport controls are unspecified

The API uses bearer-token examples, but cookie/session behavior, CSRF strategy, CORS restrictions, secure transport, and refresh-token handling are not implemented or documented.

Remediation: for cookies use SameSite and CSRF tokens; for bearer tokens use secure storage and strict CORS. Require HTTPS and define token lifetime/revocation behavior.

## Medium

### M1 — Permission revocation is only represented by interfaces

The authorization service re-checks client access, which is correct, but no live portal/local provider is connected to conversation, message, attachment, notification, or record controllers. Revocation behavior cannot currently be proven end to end.

### M2 — Group authorization is not transactionally enforced in a real database

The group service validates all participants before calling `createGroup`, but the repository transaction boundary is an interface only. Concurrent membership changes could create races unless the database operation is transactional and constraints are applied.

### M3 — Input validation is incomplete

Message text, conversation identifiers, group names, record IDs, filenames, metadata, pagination limits, and query parameters need schema validation and maximum lengths. The UI trims messages, but server validation is authoritative.

### M4 — Audit logging is incomplete

Attachment access events are represented by a repository interface. There is no wired audit sink for conversation access, denied access, participant changes, message operations, record opens, authentication failures, or permission-revocation decisions.

### M5 — Sensitive data exposure risk in logs and error handling

Error strings expose internal reason codes, and no structured logging/redaction policy is present. Storage keys, JWTs, message content, attachment metadata, and client/account identifiers must not be logged casually.

### M6 — Notification and attachment browser routes are not protected in the current API

The frontend assumes routes such as `/api/chat/notifications/unread` and attachment access routes. Since these controllers do not exist, their eventual implementations must not default to public or permissive behavior.

## Low

### L1 — XSS risk is currently low but needs regression tests

React escapes interpolated message and filename text, and no `dangerouslySetInnerHTML` was found. This does not protect future rich-text/HTML rendering or unsafe document previews.

Remediation: keep messages plain text by default, sanitize any future rich text, apply restrictive CSP, and treat uploaded documents as untrusted.

### L2 — SQL/ORM injection risk is currently low but unverified at runtime

Prisma schema/migration artifacts are used and no raw SQL interpolation was found in application services. Prisma client wiring is absent, so production query behavior and authorization filters have not been verified.

### L3 — WebSocket risks are not currently exploitable because no WebSocket exists

No WebSocket infrastructure, authentication, subscription handler, or authorization check is present. If added later, authenticate the handshake, bind identity server-side, authorize every conversation subscription, and re-check access after revocation.

## Informational

### I1 — Local identity provider is development-only

`LocalIdentityProvider` uses in-memory users, permissions, and client access. It is suitable for local development only and must not be used as the production authority.

### I2 — No email notification infrastructure exists

No email provider or existing application notification system was found, so email notification integration was correctly not added.

### I3 — Security tests are not executable in the current environment

Tests exist for authorization, uploads, attachment access, groups, notifications, identity, and record permissions, but Node’s test runner fails with Windows `spawn EPERM`. TypeScript builds also cannot run because dependencies are not installed.

### I4 — Database migrations and runtime configuration are incomplete

Schema and migration artifacts exist, but Prisma CLI, PostgreSQL connectivity, migration execution, backups, and secret management are not configured in this workspace.

## Review conclusion

Do not deploy this scaffold. Before production, resolve all Critical and High findings, wire the identity and repository adapters, add protected controllers, configure private storage and malware scanning, add rate limiting and CSRF/session controls as applicable, and run the security test suite in a working dependency/database environment.
