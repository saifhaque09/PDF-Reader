# External Chat Plugin

Standalone Chat plugin for embedding in an Accounting Portal.

## Architecture

- `apps/api`: NestJS API with OIDC/JWT boundary
- `apps/web`: React + TypeScript plugin UI
- `packages/contracts`: shared API/domain contracts
- PostgreSQL + Prisma for Chat-owned data

## Current scope

Foundation only: authenticated portal-user references, conversations, participants, and an empty inbox shell. Messaging, attachments, WebSockets, notifications, groups, and advanced search are intentionally not implemented.

## Configuration

Copy `.env.example` to `.env` and provide the portal issuer, audience, and JWT settings. The API expects the portal to authenticate users; it does not provide registration or login.
