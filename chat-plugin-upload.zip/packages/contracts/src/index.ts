export type ChatUser = { id: string; portalUserId: string; status: 'ACTIVE' | 'INACTIVE' };
export type Conversation = { id: string; type: 'ONE_TO_ONE' | 'GROUP'; name?: string; clientId?: string; status: 'ACTIVE' | 'ARCHIVED' };
export type ConversationParticipant = { conversationId: string; chatUserId: string; role: 'OWNER' | 'ADMIN' | 'MEMBER'; status: 'ACTIVE' | 'LEFT' };
