import test from 'node:test';
import assert from 'node:assert/strict';

test('foundation conversation contract is one-to-one only', () => {
  const conversation = { id: 'c1', type: 'ONE_TO_ONE', status: 'ACTIVE' };
  assert.equal(conversation.type, 'ONE_TO_ONE');
  assert.equal(conversation.status, 'ACTIVE');
});

test('chat user contract references portal identity', () => {
  const user = { id: 'chat-1', portalUserId: 'portal-1', status: 'ACTIVE' };
  assert.ok(user.portalUserId);
  assert.equal(user.status, 'ACTIVE');
});

test('participant contract has a role and belongs to a conversation', () => {
  const participant = { conversationId: 'c1', chatUserId: 'u1', role: 'OWNER', status: 'ACTIVE' };
  assert.equal(participant.role, 'OWNER');
  assert.equal(participant.status, 'ACTIVE');
});
